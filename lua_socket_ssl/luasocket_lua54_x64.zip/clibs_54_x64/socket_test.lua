local path     = _G.getScriptPath and _G.getScriptPath() or (arg[0]:gsub('[^\\/]*$', '', 1):gsub('\\', '/'))

local libs_Path = path
package.cpath 	= libs_Path.."\\?.dll;"..libs_Path.."\\?\\?.dll;"..package.cpath
package.path  	= path .."\\?.lua;"..libs_Path .."\\?\\?.lua;"..path .."\\?\\init.lua;"..package.path

if _G.message then
	_G.print = function(...)
	   local n = select('#', ...)
	   if n == 1 then
		  _G.message(tostring(select(1, ...)))
		  return
	   end
	   local t = {}
	   for i = 1, n do
		  t[#t + 1] = tostring((select(i, ...)))
	   end
	   _G.message(table.concat(t, " "))
	end
 end

local socket = require("socket")
local host = "ya.ru"
local port = 80

if arg then
	host = arg[1] or host
	port = arg[2] or port
end

_G.print(os.clock(), "Attempting connection to host '" ..host.. "' and port " ..port.. "...")
c = assert(socket.connect(host, port))
_G.print(os.clock(), "Connected!")
